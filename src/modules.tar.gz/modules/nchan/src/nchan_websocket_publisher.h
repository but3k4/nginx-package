void nchan_websocket_publisher_llist_init();
ngx_int_t nchan_create_websocket_publisher(ngx_http_request_t  *r);